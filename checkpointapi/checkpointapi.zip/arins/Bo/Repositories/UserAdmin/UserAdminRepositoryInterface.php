<?php

namespace Arins\Bo\Repositories\UserAdmin;

use Arins\Repositories\Data\DataRepositoryInterface;

//Inherit interface to DataRepositoryInterface
interface UserAdminRepositoryInterface extends DataRepositoryInterface
{
}