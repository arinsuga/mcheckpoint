<?php
namespace Arins\Helpers\Converter\Number;

interface ConvertStringToNumberInterface
{
    /**
     * ======================================================
     * 1. Date Standard 3 Methods
     * ====================================================== */
    public function strToNumber($data);

}
