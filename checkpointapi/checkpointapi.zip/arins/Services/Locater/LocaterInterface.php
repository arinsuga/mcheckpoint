<?php
namespace Arins\Services\Locater;

interface LocaterInterface
{
    /**
     * ======================================================
     * Basic
     * ====================================================== */
    function locate($par1 = null);
    
}
