<?php
namespace Arins\Services\Response;

interface ResponseInterface
{
    public function viewModel($parData);
}
