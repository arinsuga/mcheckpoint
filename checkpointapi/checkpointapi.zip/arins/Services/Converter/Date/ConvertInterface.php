<?php
namespace Arins\Services\Converter\Date;

interface ConvertInterface extends ConvertStringToDateInterface
{
    /**
     * ======================================================
     * 1. Inherit from ConvertStringToDateInterface
     * ====================================================== */

}
