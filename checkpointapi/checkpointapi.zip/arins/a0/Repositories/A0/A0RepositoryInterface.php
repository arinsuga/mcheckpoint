<?php

namespace Arins\A0\Repositories\A0;

use Arins\Repositories\Data\DataRepositoryInterface;

//Inherit interface to BaseRepositoryInterface
interface A0RepositoryInterface extends DataRepositoryInterface
{
}